using System;

namespace DojoSurveyModel.Models {
    public class Survey {
        // your Survey fields go here
        public string Name { get; set; }
        public string Location { get; set; }
        public string Language { get; set; }
        public string Comments { get; set; }
    }
}