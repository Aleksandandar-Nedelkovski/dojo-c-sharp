using System;

namespace RandomPasscode.Models
{
    public class MyModel
    {
       
    }
}